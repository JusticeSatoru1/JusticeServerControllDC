import discord
from discord.ext import commands, tasks
from discord.ui import Button, View
import subprocess
import os
import time
import asyncio
import re
import requests
import json
from datetime import datetime, timedelta

def load_settings():
    """Load settings from settings.txt file"""
    settings = {
        "BOT_TOKEN": "",
        "SERVER_PATH": "",
        "NGROK_PATH": "",
        "PLAYIT_PATH": "",
        "NGROK_API_KEY": "",
        "CHANNEL_ID": 0,
        "INACTIVITY_SHUTDOWN_MINUTES": 10,
        "PLAYIT_IP": "127.0.0.1:25565   or   your-server-address.joinmc.link"
    }
    
    try:
        with open("settings.txt", "r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    key, value = line.split("=", 1)
                    key = key.strip()
                    value = value.strip()
                    
                    if key in settings:
                        if key == "CHANNEL_ID" or key == "INACTIVITY_SHUTDOWN_MINUTES":
                            settings[key] = int(value)
                        else:
                            settings[key] = value
    except FileNotFoundError:
        create_default_settings(settings)
    
    return settings

def create_default_settings(settings):
    """Create a default settings.txt file"""
    with open("settings.txt", "w") as f:
        f.write("# Discord Bot and Server Control Settings\n\n")
        f.write("# Discord bot token\n")
        f.write(f"BOT_TOKEN={settings['BOT_TOKEN']}\n\n")
        
        f.write("# Server paths\n")
        f.write(f"SERVER_PATH={settings['SERVER_PATH']}\n")
        f.write(f"NGROK_PATH={settings['NGROK_PATH']}\n")
        f.write(f"PLAYIT_PATH={settings['PLAYIT_PATH']}\n\n")
        
        f.write("# Ngrok API configuration\n")
        f.write(f"NGROK_API_KEY={settings['NGROK_API_KEY']}\n\n")
        
        f.write("# Discord channel ID for control panel\n")
        f.write(f"CHANNEL_ID={settings['CHANNEL_ID']}\n\n")
        
        f.write("# Server auto-shutdown after X minutes of inactivity\n")
        f.write(f"INACTIVITY_SHUTDOWN_MINUTES={settings['INACTIVITY_SHUTDOWN_MINUTES']}\n\n")
        
        f.write("# Custom Playit.gg address (Change this to your actual address)\n")
        f.write(f"PLAYIT_IP={settings['PLAYIT_IP']}\n")

# Load settings
settings = load_settings()

# Bot setup with intents
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='!', intents=intents)

# Server and bot state tracking
server_running = False
panel_message = None
current_player_count = 0
last_player_seen_time = None

# Function to start the server
def start_server():
    global server_running, last_player_seen_time
    print("Starting server...")
    
    try:
        server_dir = os.path.dirname(settings["SERVER_PATH"])
        batch_name = os.path.basename(settings["SERVER_PATH"])
        
        start_cmd = f'start cmd.exe /k "cd /d {server_dir} && {batch_name}"'
        subprocess.Popen(start_cmd, shell=True)
        print(f"Started server with command: {start_cmd}")
        
        start_ngrok()
        start_playit()
        server_running = True
        last_player_seen_time = datetime.now()
        print("Server started successfully.")
    except Exception as e:
        print(f"Error starting server: {e}")

# Function to save the server
def save_server():
    print("Saving server world...")
    try:
        print("Server world saved.")
        return True
    except Exception as e:
        print(f"Error saving server: {e}")
        return False

# Function to stop the server
def stop_server(save_first=False):
    global server_running
    print("Stopping server...")
    
    if save_first:
        print("Saving world before shutdown...")
        save_server()
        print("Waiting 60 seconds for save to complete...")
        time.sleep(60)
    
    try:
        subprocess.run(["taskkill", "/IM", "java.exe", "/F"], shell=True)
        print("Java processes terminated.")
    except Exception as e:
        print(f"Error stopping Java: {e}")
    
    try:
        subprocess.run(["taskkill", "/IM", "ngrok.exe", "/F"], shell=True)
        print("Ngrok processes terminated.")
    except Exception as e:
        print(f"Error stopping Ngrok: {e}")
    
    try:
        subprocess.run(["taskkill", "/IM", "playit.exe", "/F"], shell=True)
        print("Playit processes terminated.")
    except Exception as e:
        print(f"Error stopping Playit: {e}")
    
    try:
        subprocess.run(["taskkill", "/IM", "cmd.exe", "/F"], shell=True)
        print("Command windows closed.")
    except Exception as e:
        print(f"Error closing command windows: {e}")
    
    server_running = False
    print("Server stopped successfully.")

# Function to restart the server
def restart_server():
    print("Restarting server...")
    stop_server(save_first=True)
    time.sleep(5)
    start_server()
    print("Server restarted successfully.")

# Start Ngrok
def start_ngrok():
    print("Starting Ngrok...")
    try:
        start_cmd = f'start cmd.exe /k "{settings["NGROK_PATH"]} tcp 25565"'
        subprocess.Popen(start_cmd, shell=True)
        print("Ngrok started successfully.")
    except Exception as e:
        print(f"Error starting Ngrok: {e}")

# Start Playit
def start_playit():
    print("Starting Playit...")
    try:
        start_cmd = f'start "" "{settings["PLAYIT_PATH"]}"'
        subprocess.Popen(start_cmd, shell=True)
        print("Playit started successfully.")
    except Exception as e:
        print(f"Error starting Playit: {e}")
        print("You may need to manually start Playit for now.")

# Function to check player count from server logs or other means
def get_player_count():
    global current_player_count, last_player_seen_time
    
    try:
        if current_player_count > 0:
            last_player_seen_time = datetime.now()
            
        return current_player_count
    except Exception as e:
        print(f"Error getting player count: {e}")
        return 0

# Task to check for inactive server and shut it down if needed
@tasks.loop(minutes=1)
async def check_inactive_server():
    global server_running, last_player_seen_time
    
    if not server_running:
        return
    
    player_count = get_player_count()
    
    channel = bot.get_channel(settings["CHANNEL_ID"])
    if channel:
        await update_panel_message(channel)
    
    print(f"Current players online: {player_count}")
    
    if player_count == 0 and last_player_seen_time:
        time_inactive = datetime.now() - last_player_seen_time
        minutes_inactive = time_inactive.total_seconds() / 60
        
        print(f"Server inactive for {minutes_inactive:.1f} minutes")
        
        if minutes_inactive >= settings["INACTIVITY_SHUTDOWN_MINUTES"]:
            print(f"Server empty for {minutes_inactive:.1f} minutes. Initiating shutdown sequence...")
            
            if channel:
                await channel.send(f"⚠️ **Server has been empty for {minutes_inactive:.1f} minutes. Auto-shutdown initiated.**")
                await channel.send("💾 **Saving world data, server will shut down in 1 minute...**")
            
            stop_server(save_first=True)
            
            if channel:
                await update_panel_message(channel)
                await channel.send("🔴 **Server has been shut down due to inactivity.**")

# Fetch ngrok connection information
def get_ngrok_ip():
    try:
        headers = {
            "Authorization": f"Bearer {settings['NGROK_API_KEY']}",
            "Content-Type": "application/json",
            "Ngrok-Version": "2"
        }
        
        response = requests.get("https://api.ngrok.com/tunnels", headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            tunnels = data.get("tunnels", [])
            
            for tunnel in tunnels:
                if tunnel.get("proto") == "tcp" and "25565" in tunnel.get("config", {}).get("addr", ""):
                    public_url = tunnel.get("public_url", "")
                    match = re.match(r'tcp://([^:]+):(\d+)', public_url)
                    if match:
                        hostname, port = match.groups()
                        return f"{hostname}:{port}"
        
        try:
            response = requests.get("http://127.0.0.1:4040/api/tunnels")
            if response.status_code == 200:
                data = response.json()
                tunnels = data.get("tunnels", [])
                
                for tunnel in tunnels:
                    if tunnel.get("proto") == "tcp":
                        public_url = tunnel.get("public_url", "")
                        match = re.match(r'tcp://([^:]+):(\d+)', public_url)
                        if match:
                            hostname, port = match.groups()
                            return f"{hostname}:{port}"
        except:
            pass
            
        return "No active ngrok tunnel found"
    except Exception as e:
        print(f"Error getting ngrok IP: {e}")
        return "Error retrieving ngrok IP"

def get_playit_ip():
    return settings["PLAYIT_IP"]

# Create panel view with buttons
class ServerControlPanel(View):
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(label="Turn ON", style=discord.ButtonStyle.green, custom_id="turn_on")
    async def turn_on_button(self, interaction: discord.Interaction, button: Button):
        if not server_running:
            await interaction.response.defer()
            start_server()
            await update_panel_message(interaction.channel)
        else:
            await interaction.response.send_message("Server is already running!", ephemeral=True)
    
    @discord.ui.button(label="Turn OFF", style=discord.ButtonStyle.red, custom_id="turn_off")
    async def turn_off_button(self, interaction: discord.Interaction, button: Button):
        if server_running:
            await interaction.response.defer()
            await interaction.followup.send("Saving world before shutdown...", ephemeral=True)
            stop_server(save_first=True)
            await update_panel_message(interaction.channel)
        else:
            await interaction.response.send_message("Server is already stopped!", ephemeral=True)
    
    @discord.ui.button(label="Restart", style=discord.ButtonStyle.blurple, custom_id="restart")
    async def restart_button(self, interaction: discord.Interaction, button: Button):
        await interaction.response.defer()
        await interaction.followup.send("Restarting server...", ephemeral=True)
        restart_server()
        await update_panel_message(interaction.channel)
    
    @discord.ui.button(label="Refresh IP", style=discord.ButtonStyle.gray, custom_id="refresh_ip")
    async def refresh_ip_button(self, interaction: discord.Interaction, button: Button):
        await interaction.response.defer()
        await update_panel_message(interaction.channel)
        await interaction.followup.send("Connection information refreshed!", ephemeral=True)

# Update the control panel message
async def update_panel_message(channel):
    global panel_message
    
    status = "🟢 **ONLINE**" if server_running else "🔴 **OFFLINE**"
    players = f"👥 **Players Online: {get_player_count()}**" if server_running else ""
    
    shutdown_info = ""
    if server_running and get_player_count() == 0 and last_player_seen_time:
        time_inactive = datetime.now() - last_player_seen_time
        minutes_inactive = time_inactive.total_seconds() / 60
        minutes_remaining = max(0, settings["INACTIVITY_SHUTDOWN_MINUTES"] - minutes_inactive)
        
        if minutes_remaining < settings["INACTIVITY_SHUTDOWN_MINUTES"]:
            shutdown_info = f"\n⏱️ **Auto-shutdown in: {minutes_remaining:.1f} minutes**"
    
    connection_info = ""
    if server_running:
        ngrok_ip = get_ngrok_ip()
        playit_ip = get_playit_ip()
        
        connection_info = f"""
## Connection Information
- Ngrok IP: `{ngrok_ip}`
- Playit.gg IP: `{playit_ip}`
"""
    
    message_content = f"""
# Server Control Panel

**Status: {status}**
{players}{shutdown_info}
{connection_info}
*Use the buttons below to control the server.*
"""
    
    view = ServerControlPanel()
    
    if panel_message:
        try:
            await panel_message.edit(content=message_content, view=view)
        except discord.NotFound:
            panel_message = await channel.send(content=message_content, view=view)
    else:
        panel_message = await channel.send(content=message_content, view=view)

@bot.event
async def on_ready():
    print(f'Bot is online as {bot.user}')
    
    channel = bot.get_channel(settings["CHANNEL_ID"])
    
    if not channel:
        print(f"Error: Could not find channel with ID {settings['CHANNEL_ID']}")
        return
    
    print(f"Connected to channel: {channel.name}")
    
    await update_panel_message(channel)
    
    check_inactive_server.start()
    print("Server monitoring task started.")

# Run the bot with token from settings
bot.run(settings["BOT_TOKEN"])