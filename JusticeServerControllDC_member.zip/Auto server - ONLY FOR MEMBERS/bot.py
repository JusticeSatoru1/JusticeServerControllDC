import discord
from discord.ext import commands, tasks
from discord.ui import Button, View
import subprocess
import os
import time
import asyncio
import re
import requests
import json
from datetime import datetime, timedelta
import sys
import threading
import tempfile

def load_settings():
    """Load settings from settings.txt file"""
    settings = {
        "BOT_TOKEN": "",
        "SERVER_PATH": "",
        "NGROK_PATH": "",
        "PLAYIT_PATH": "",
        "NGROK_API_KEY": "",
        "CHANNEL_ID": 0,
        "INACTIVITY_SHUTDOWN_MINUTES": 10,
        "PLAYIT_IP": "127.0.0.1:25565   or   your-server-address.joinmc.link"
    }
    
    try:
        with open("settings.txt", "r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    try:
                        key, value = line.split("=", 1)
                        key = key.strip()
                        value = value.strip()
                        
                        if key in settings:
                            if key == "CHANNEL_ID" or key == "INACTIVITY_SHUTDOWN_MINUTES":
                                if value:  # Only convert if not empty
                                    settings[key] = int(value)
                            else:
                                settings[key] = value
                    except ValueError:
                        print(f"Warning: Invalid line in settings.txt: {line}")
    except FileNotFoundError:
        create_default_settings(settings)
        print("Created new settings.txt file. Please edit it with your configuration.")
        sys.exit(1)
    
    # Validate required settings
    missing_required = []
    if not settings["BOT_TOKEN"]:
        missing_required.append("BOT_TOKEN")
    if not settings["SERVER_PATH"]:
        missing_required.append("SERVER_PATH")
    if not settings["CHANNEL_ID"]:
        missing_required.append("CHANNEL_ID")
    
    if missing_required:
        print(f"Error: The following required settings are missing or empty: {', '.join(missing_required)}")
        print("Please edit settings.txt to provide these values.")
        sys.exit(1)
        
    return settings

def create_default_settings(settings):
    """Create a default settings.txt file"""
    with open("settings.txt", "w") as f:
        f.write("# Discord Bot and Server Control Settings\n\n")
        f.write("# Discord bot token\n")
        f.write(f"BOT_TOKEN={settings['BOT_TOKEN']}\n\n")
        
        f.write("# Server paths\n")
        f.write("# Change the locations those are only Examples\n")
        f.write(f"SERVER_PATH={settings['SERVER_PATH']}\n")
        f.write(f"NGROK_PATH={settings['NGROK_PATH']}\n")
        f.write(f"PLAYIT_PATH={settings['PLAYIT_PATH']}\n\n")
        
        f.write("# Ngrok API configuration\n")
        f.write(f"NGROK_API_KEY={settings['NGROK_API_KEY']}\n\n")
        
        f.write("# Discord channel ID for control panel\n")
        f.write(f"CHANNEL_ID={settings['CHANNEL_ID']}\n\n")
        
        f.write("# Server auto-shutdown after X minutes of inactivity\n")
        f.write(f"INACTIVITY_SHUTDOWN_MINUTES={settings['INACTIVITY_SHUTDOWN_MINUTES']}\n\n")
        
        f.write("# Custom Playit.gg address (Change this to your actual address)\n")
        f.write(f"PLAYIT_IP={settings['PLAYIT_IP']}\n")

print("Loading settings...")
settings = load_settings()
print("Settings loaded successfully.")

# Configure intents based on what we need
intents = discord.Intents.default()
intents.message_content = True  # This is a privileged intent

# Check if the user should enable privileged intents
try:
    print("Creating bot instance...")
    bot = commands.Bot(command_prefix='!', intents=intents)
    print("Bot instance created.")
except Exception as e:
    print("Error creating bot instance. Please make sure you've enabled privileged intents.")
    print("Go to https://discord.com/developers/applications/ and enable the Message Content Intent.")
    print(f"Error details: {e}")
    sys.exit(1)

# Server and bot state tracking
server_running = False
panel_message = None
current_player_count = 0
last_player_seen_time = None
server_process = None
log_monitoring_thread = None
stop_monitoring = False
server_log_file = None

# Create a log file path for capturing server output
log_file_path = os.path.join(tempfile.gettempdir(), "minecraft_server_log.txt")

# Function to read server output and write to log file
def monitor_server_output():
    global stop_monitoring
    
    if not os.path.exists(log_file_path):
        open(log_file_path, 'w').close()
    
    with open(log_file_path, 'a', encoding='utf-8', errors='ignore') as log_file:
        log_file.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] Server monitoring started\n")
        log_file.flush()
    
    print(f"Server output monitoring started. Log file: {log_file_path}")

# Function to monitor server logs for player join/leave events
def monitor_server_logs():
    global current_player_count, last_player_seen_time, stop_monitoring, server_log_file
    
    print(f"Starting server log monitoring from {log_file_path}...")
    
    join_pattern = re.compile(r"(\w+)\[.+\] logged in with entity id")
    leave_pattern = re.compile(r"(\w+) left the game")
    
    player_set = set()  # Keep track of connected players by username
    
    # Wait briefly for the server to start and create the log file
    for _ in range(10):
        if os.path.exists(log_file_path):
            break
        time.sleep(1)
    
    if not os.path.exists(log_file_path):
        print(f"Warning: Log file {log_file_path} not found after waiting")
        return
        
    try:
        # Open the log file and seek to the end
        with open(log_file_path, 'r', encoding='utf-8', errors='ignore') as log_file:
            # Go to the end of the file
            log_file.seek(0, os.SEEK_END)
            
            # Monitor for new content
            while not stop_monitoring:
                line = log_file.readline()
                if not line:
                    # No new content, wait briefly and try again
                    time.sleep(0.1)
                    continue
                
                # Check for player join events
                join_match = join_pattern.search(line)
                if join_match:
                    username = join_match.group(1)
                    if username not in player_set:
                        player_set.add(username)
                        current_player_count = len(player_set)
                        last_player_seen_time = datetime.now()
                        print(f"Player joined: {username}, Current count: {current_player_count}")
                
                # Check for player leave events
                leave_match = leave_pattern.search(line)
                if leave_match:
                    username = leave_match.group(1)
                    if username in player_set:
                        player_set.remove(username)
                        current_player_count = len(player_set)
                        if current_player_count > 0:
                            last_player_seen_time = datetime.now()
                        print(f"Player left: {username}, Current count: {current_player_count}")
    except Exception as e:
        print(f"Error in log monitoring: {e}")
    
    print("Server log monitoring stopped.")

# Start background log copier
def start_log_copier():
    # PowerShell command to tail the Minecraft server log and write to our monitoring file
    powershell_cmd = (
        f"powershell -Command \"" +
        f"$logFile = '{log_file_path}';" +
        f"'[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] Server log monitoring started' | Out-File -FilePath $logFile -Encoding utf8;" +
        f"Get-Content -Path $logFile -Wait" +
        f"\""
    )
    
    # Start PowerShell in a hidden window
    subprocess.Popen(powershell_cmd, shell=True, creationflags=subprocess.CREATE_NO_WINDOW)

# Function to start the server
def start_server():
    global server_running, last_player_seen_time, server_process, log_monitoring_thread, stop_monitoring, server_log_file
    print("Starting server...")
    
    try:
        if not os.path.exists(settings["SERVER_PATH"]):
            print(f"Error: SERVER_PATH does not exist: {settings['SERVER_PATH']}")
            return False
            
        server_dir = os.path.dirname(settings["SERVER_PATH"])
        batch_name = os.path.basename(settings["SERVER_PATH"])
        
        # Create a modified batch file that shows the console and also logs output
        temp_batch_path = os.path.join(tempfile.gettempdir(), "minecraft_server_wrapper.bat")
        with open(temp_batch_path, "w") as temp_batch:
            temp_batch.write(f"@echo off\n")
            temp_batch.write(f"cd /d {server_dir}\n")
            temp_batch.write(f"echo Starting Minecraft Server...\n")
            
            # Run the server batch file and use PowerShell to tee output to our log file
            temp_batch.write(f"powershell -Command \"& {{" +
                f"$log = '{log_file_path}';" +
                f"'[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] Server started' | Out-File -FilePath $log -Encoding utf8 -Force;" +
                f"cmd /c {batch_name} | Tee-Object -FilePath $log -Append" +
                f"}}\"\n")
        
        # Make sure log file is clear
        open(log_file_path, 'w').close()
        
        # Start the server with a visible window
        server_process = subprocess.Popen(
            f'start cmd.exe /k "{temp_batch_path}"',
            shell=True
        )
        
        print(f"Started server with process ID: {server_process.pid}")
        
        # Reset monitoring flag
        stop_monitoring = False
        
        # Start monitoring thread
        log_monitoring_thread = threading.Thread(target=monitor_server_logs)
        log_monitoring_thread.daemon = True
        log_monitoring_thread.start()
        
        # Only try to start ngrok if path is provided
        if settings["NGROK_PATH"]:
            start_ngrok()
        else:
            print("Ngrok path not configured, skipping ngrok startup.")
        
        # Only try to start playit if path is provided
        if settings["PLAYIT_PATH"]:
            start_playit()
        else:
            print("Playit path not configured, skipping playit startup.")
            
        server_running = True
        last_player_seen_time = datetime.now()
        current_player_count = 0  # Reset player count
        print("Server started successfully.")
        return True
    except Exception as e:
        print(f"Error starting server: {e}")
        return False

# Function to save the server
def save_server():
    print("Saving server world...")
    try:
        # Create a new command window to send the save-all command to the server
        save_cmd = f'start cmd.exe /k "cd /d {os.path.dirname(settings["SERVER_PATH"])} && title Minecraft Server - Saving && echo Sending save-all command... && echo save-all > con && timeout /t 5 && exit"'
        subprocess.Popen(save_cmd, shell=True)
        print("Server world save command sent.")
        return True
    except Exception as e:
        print(f"Error saving server: {e}")
        return False

# Function to stop the server
def stop_server(save_first=False):
    global server_running, server_process, stop_monitoring
    print("Stopping server...")
    
    # Signal the monitoring thread to stop
    stop_monitoring = True
    
    if save_first:
        print("Saving world before shutdown...")
        save_server()
        print("Waiting 10 seconds for save to complete...")
        time.sleep(10)
    
    try:
        # Create a new command window to send the stop command to the server
        stop_cmd = f'start cmd.exe /k "cd /d {os.path.dirname(settings["SERVER_PATH"])} && title Minecraft Server - Stopping && echo Sending stop command... && echo stop > con && timeout /t 10 && exit"'
        subprocess.Popen(stop_cmd, shell=True)
        print("Server stop command sent.")
        
        # Wait a bit before force-killing if needed
        time.sleep(15)
        
        # Force kill Java if still running
        subprocess.run(["taskkill", "/IM", "java.exe", "/F"], shell=True)
        print("Java processes terminated.")
    except Exception as e:
        print(f"Error stopping Java: {e}")
    
    # Only try to stop ngrok if path is configured
    if settings["NGROK_PATH"]:
        try:
            subprocess.run(["taskkill", "/IM", "ngrok.exe", "/F"], shell=True)
            print("Ngrok processes terminated.")
        except Exception as e:
            print(f"Error stopping Ngrok: {e}")
    
    # Only try to stop playit if path is configured
    if settings["PLAYIT_PATH"]:
        try:
            subprocess.run(["taskkill", "/IM", "playit.exe", "/F"], shell=True)
            print("Playit processes terminated.")
        except Exception as e:
            print(f"Error stopping Playit: {e}")
    
    server_running = False
    current_player_count = 0
    print("Server stopped successfully.")

# Function to restart the server
def restart_server():
    print("Restarting server...")
    stop_server(save_first=True)
    time.sleep(5)
    if start_server():
        print("Server restarted successfully.")
    else:
        print("Failed to restart server.")

# Start Ngrok
def start_ngrok():
    if not settings["NGROK_PATH"]:
        print("Ngrok path not configured, skipping.")
        return
        
    print("Starting Ngrok...")
    try:
        if not os.path.exists(settings["NGROK_PATH"]):
            print(f"Error: NGROK_PATH does not exist: {settings['NGROK_PATH']}")
            return
            
        start_cmd = f'start cmd.exe /k "{settings["NGROK_PATH"]} tcp 25565"'
        subprocess.Popen(start_cmd, shell=True)
        print("Ngrok started successfully.")
    except Exception as e:
        print(f"Error starting Ngrok: {e}")

# Start Playit
def start_playit():
    if not settings["PLAYIT_PATH"]:
        print("Playit path not configured, skipping.")
        return
        
    print("Starting Playit...")
    try:
        if not os.path.exists(settings["PLAYIT_PATH"]):
            print(f"Error: PLAYIT_PATH does not exist: {settings['PLAYIT_PATH']}")
            return
            
        start_cmd = f'start "" "{settings["PLAYIT_PATH"]}"'
        subprocess.Popen(start_cmd, shell=True)
        print("Playit started successfully.")
    except Exception as e:
        print(f"Error starting Playit: {e}")
        print("You may need to manually start Playit for now.")

# Function to get the current player count
def get_player_count():
    global current_player_count, last_player_seen_time
    
    # The count is now maintained by the log monitoring thread
    return current_player_count

# Task to check for inactive server and shut it down if needed
@tasks.loop(minutes=1)
async def check_inactive_server():
    global server_running, last_player_seen_time
    
    if not server_running:
        return
    
    player_count = get_player_count()
    
    channel = bot.get_channel(settings["CHANNEL_ID"])
    if channel:
        await update_panel_message(channel)
    else:
        print(f"Warning: Cannot find channel with ID {settings['CHANNEL_ID']}")
    
    print(f"Current players online: {player_count}")
    
    if player_count == 0 and last_player_seen_time:
        time_inactive = datetime.now() - last_player_seen_time
        minutes_inactive = time_inactive.total_seconds() / 60
        
        print(f"Server inactive for {minutes_inactive:.1f} minutes")
        
        if minutes_inactive >= settings["INACTIVITY_SHUTDOWN_MINUTES"]:
            print(f"Server empty for {minutes_inactive:.1f} minutes. Initiating shutdown sequence...")
            
            if channel:
                await channel.send(f"⚠️ **Server has been empty for {minutes_inactive:.1f} minutes. Auto-shutdown initiated.**")
                await channel.send("💾 **Saving world data, server will shut down in 1 minute...**")
            
            stop_server(save_first=True)
            
            if channel:
                await update_panel_message(channel)
                await channel.send("🔴 **Server has been shut down due to inactivity.**")

# Fetch ngrok connection information
def get_ngrok_ip():
    if not settings["NGROK_API_KEY"] or not settings["NGROK_PATH"]:
        return "Ngrok not configured"
    
    try:
        headers = {
            "Authorization": f"Bearer {settings['NGROK_API_KEY']}",
            "Content-Type": "application/json",
            "Ngrok-Version": "2"
        }
        
        response = requests.get("https://api.ngrok.com/tunnels", headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            tunnels = data.get("tunnels", [])
            
            for tunnel in tunnels:
                if tunnel.get("proto") == "tcp" and "25565" in tunnel.get("config", {}).get("addr", ""):
                    public_url = tunnel.get("public_url", "")
                    match = re.match(r'tcp://([^:]+):(\d+)', public_url)
                    if match:
                        hostname, port = match.groups()
                        return f"{hostname}:{port}"
        
        # Fallback to local API if available
        try:
            response = requests.get("http://127.0.0.1:4040/api/tunnels")
            if response.status_code == 200:
                data = response.json()
                tunnels = data.get("tunnels", [])
                
                for tunnel in tunnels:
                    if tunnel.get("proto") == "tcp":
                        public_url = tunnel.get("public_url", "")
                        match = re.match(r'tcp://([^:]+):(\d+)', public_url)
                        if match:
                            hostname, port = match.groups()
                            return f"{hostname}:{port}"
        except:
            pass
            
        return "No active ngrok tunnel found"
    except Exception as e:
        print(f"Error getting ngrok IP: {e}")
        return "Error retrieving ngrok IP"

def get_playit_ip():
    # Return the configured value or a default message
    return settings["PLAYIT_IP"] if settings["PLAYIT_IP"] else "Playit.gg not configured"

# Create panel view with buttons
class ServerControlPanel(View):
    def __init__(self):
        super().__init__(timeout=None)  # Buttons never timeout
    
    @discord.ui.button(label="Turn ON", style=discord.ButtonStyle.green, custom_id="turn_on")
    async def turn_on_button(self, interaction: discord.Interaction, button: Button):
        if not server_running:
            await interaction.response.defer()
            if start_server():
                await update_panel_message(interaction.channel)
            else:
                await interaction.followup.send("Failed to start server. Check console for details.", ephemeral=True)
        else:
            await interaction.response.send_message("Server is already running!", ephemeral=True)
    
    @discord.ui.button(label="Refresh IP", style=discord.ButtonStyle.gray, custom_id="refresh_ip")
    async def refresh_ip_button(self, interaction: discord.Interaction, button: Button):
        await interaction.response.defer()
        await update_panel_message(interaction.channel)
        await interaction.followup.send("Connection information refreshed!", ephemeral=True)

# Update the control panel message
async def update_panel_message(channel):
    global panel_message
    
    status = "🟢 **ONLINE**" if server_running else "🔴 **OFFLINE**"
    players = f"👥 **Players Online: {get_player_count()}**" if server_running else ""
    
    shutdown_info = ""
    if server_running and get_player_count() == 0 and last_player_seen_time:
        time_inactive = datetime.now() - last_player_seen_time
        minutes_inactive = time_inactive.total_seconds() / 60
        minutes_remaining = max(0, settings["INACTIVITY_SHUTDOWN_MINUTES"] - minutes_inactive)
        
        if minutes_remaining < settings["INACTIVITY_SHUTDOWN_MINUTES"]:
            shutdown_info = f"\n⏱️ **Auto-shutdown in: {minutes_remaining:.1f} minutes**"
    
    connection_info = ""
    if server_running:
        connection_info = "## Connection Information\n"
        
        # Only show ngrok IP if configured
        if settings["NGROK_PATH"] and settings["NGROK_API_KEY"]:
            ngrok_ip = get_ngrok_ip()
            connection_info += f"- Ngrok IP: `{ngrok_ip}`\n"
        
        # Only show playit IP if configured
        if settings["PLAYIT_PATH"] and settings["PLAYIT_IP"]:
            playit_ip = get_playit_ip()
            connection_info += f"- Playit.gg IP: `{playit_ip}`\n"
        
        # If neither are configured, provide a message
        if not settings["NGROK_PATH"] and not settings["PLAYIT_PATH"]:
            connection_info += "- *No connection services configured*\n"
    
    message_content = f"""
# Server Control Panel

**Status: {status}**
{players}{shutdown_info}
{connection_info}
*Use the buttons below to control the server.*
"""
    
    view = ServerControlPanel()
    
    if panel_message:
        try:
            await panel_message.edit(content=message_content, view=view)
        except discord.NotFound:
            panel_message = await channel.send(content=message_content, view=view)
    else:
        panel_message = await channel.send(content=message_content, view=view)

@bot.event
async def on_ready():
    print(f'Bot is online as {bot.user}')
    
    channel = bot.get_channel(settings["CHANNEL_ID"])
    
    if not channel:
        print(f"Error: Could not find channel with ID {settings['CHANNEL_ID']}")
        print("Make sure the bot has access to this channel and the CHANNEL_ID is correct.")
        return
    
    print(f"Connected to channel: {channel.name}")
    
    await update_panel_message(channel)
    
    check_inactive_server.start()
    print("Server monitoring task started.")

# Provide better error reporting on startup
print(f"Starting bot with token: {settings['BOT_TOKEN'][:5]}...{settings['BOT_TOKEN'][-5:] if len(settings['BOT_TOKEN']) > 10 else ''}")
print("If the bot fails to start, check:")
print("1. Your BOT_TOKEN is correct")
print("2. You've enabled the 'Message Content Intent' at https://discord.com/developers/applications/")
print("3. The bot has been invited to your server with proper permissions")

# Run the bot with token from settings
try:
    bot.run(settings["BOT_TOKEN"])
except discord.errors.PrivilegedIntentsRequired:
    print("\nERROR: Privileged intents are required but not enabled.")
    print("Please go to https://discord.com/developers/applications/")
    print("Select your application, go to the 'Bot' tab, and enable 'Message Content Intent'.")
    sys.exit(1)
except discord.errors.LoginFailure:
    print("\nERROR: Invalid token provided.")
    print("Please check your BOT_TOKEN in settings.txt")
    sys.exit(1)
except Exception as e:
    print(f"\nERROR: Failed to start bot: {e}")
    sys.exit(1)